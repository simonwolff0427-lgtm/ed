package com.example.fullreset;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.WorldType;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.FileVisitResult;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.Random;
import java.util.concurrent.CompletableFuture;

/**
 * Handles the full lifecycle of a server reset:
 *   1) confirmation window
 *   2) countdown + kick
 *   3) unload + delete world folders
 *   4) regenerate worlds with fresh random seeds
 *   5) clear saved homes (EssentialsX userdata, if present)
 *
 * Deliberately does NOT touch: plugins/LuckPerms, plugins/WorldGuard, or any
 * spawn-protection settings — those live entirely outside the world folders
 * this plugin deletes, and this plugin never reads or writes those paths.
 */
public class ResetManager {

    private final FullResetPlugin plugin;
    private boolean pending = false;
    private BukkitTask expiryTask;
    private boolean resetInProgress = false;

    public ResetManager(FullResetPlugin plugin) {
        this.plugin = plugin;
    }

    private String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }

    private String prefixed(String key) {
        return plugin.getConfig().getString("messages.prefix", "") + plugin.getConfig().getString("messages." + key, key);
    }

    public boolean requestReset(CommandSender initiator) {
        if (pending || resetInProgress) {
            return false;
        }
        pending = true;
        int timeout = plugin.getConfig().getInt("options.confirmation-timeout-seconds", 30);
        expiryTask = Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (pending) {
                pending = false;
                initiator.sendMessage(color(prefixed("expired")));
            }
        }, timeout * 20L);
        return true;
    }

    public boolean confirmReset(CommandSender initiator) {
        if (!pending) {
            return false;
        }
        pending = false;
        if (expiryTask != null) {
            expiryTask.cancel();
            expiryTask = null;
        }
        initiator.sendMessage(color(prefixed("confirmed")));
        beginCountdownAndReset();
        return true;
    }

    public boolean cancelPending() {
        if (!pending) {
            return false;
        }
        pending = false;
        if (expiryTask != null) {
            expiryTask.cancel();
            expiryTask = null;
        }
        return true;
    }

    // ---------------------------------------------------------------
    // Countdown -> kick -> reset
    // ---------------------------------------------------------------

    private void beginCountdownAndReset() {
        resetInProgress = true;
        int seconds = plugin.getConfig().getInt("options.countdown-seconds", 15);
        String startMsg = color(prefixed("broadcast-start").replace("{seconds}", String.valueOf(seconds)));
        Bukkit.broadcastMessage(startMsg);

        tickCountdown(seconds);
    }

    private void tickCountdown(int secondsLeft) {
        if (secondsLeft <= 0) {
            kickAllAndReset();
            return;
        }
        if (secondsLeft <= 5 || secondsLeft % 5 == 0) {
            Bukkit.broadcastMessage(color(prefixed("broadcast-tick").replace("{seconds}", String.valueOf(secondsLeft))));
        }
        Bukkit.getScheduler().runTaskLater(plugin, () -> tickCountdown(secondsLeft - 1), 20L);
    }

    private void kickAllAndReset() {
        String kickMsg = color(prefixed("kick-message"));
        for (Player p : Bukkit.getOnlinePlayers().toArray(new Player[0])) {
            p.kickPlayer(kickMsg);
        }
        // Temporarily whitelist-lock joins during the reset so nobody connects mid-wipe.
        boolean wasWhitelisted = Bukkit.hasWhitelist();
        Bukkit.setWhitelist(true);

        // Poll until everyone has actually finished disconnecting (kicking is not
        // instantaneous — the player list can still be non-empty for a few ticks
        // after kickPlayer() is called), instead of assuming a fixed delay is enough.
        waitForEmptyThenReset(wasWhitelisted, 0);
    }

    private void waitForEmptyThenReset(boolean restoreWhitelist, int attempt) {
        if (!Bukkit.getOnlinePlayers().isEmpty() && attempt < 200) { // up to ~10s
            Bukkit.getScheduler().runTaskLater(plugin, () -> waitForEmptyThenReset(restoreWhitelist, attempt + 1), 1L);
            return;
        }
        doReset(restoreWhitelist);
    }

    // ---------------------------------------------------------------
    // Actual reset
    // ---------------------------------------------------------------

    private void doReset(boolean restoreWhitelist) {
        var cfg = plugin.getConfig();
        String overworldName = cfg.getString("worlds.overworld", "world");
        String netherName = cfg.getString("worlds.nether", "world_nether");
        String endName = cfg.getString("worlds.the_end", "world_the_end");

        boolean doOverworld = cfg.getBoolean("options.reset-overworld", true);
        boolean doNether = cfg.getBoolean("options.reset-nether", true);
        boolean doEnd = cfg.getBoolean("options.reset-end", true);
        boolean randomizeSeeds = cfg.getBoolean("options.randomize-seeds", true);

        long overworldSeed = randomizeSeeds ? new Random().nextLong() : currentSeedOrRandom(overworldName);
        long netherSeed = randomizeSeeds ? new Random().nextLong() : currentSeedOrRandom(netherName);
        long endSeed = randomizeSeeds ? new Random().nextLong() : currentSeedOrRandom(endName);

        // IMPORTANT: Bukkit refuses to unload the server's PRIMARY world (the one named
        // in server.properties' level-name) while the server is running — this is a
        // hardcoded restriction, not something any plugin can override live. Secondary
        // worlds (Nether, End, and anything Multiverse-style) CAN be unloaded live.
        // So: Nether/End get reset live, with no restart. The Overworld (if it's your
        // primary world) gets its folder cleared and its new seed written into
        // server.properties now, but needs one manual restart to finish generating —
        // that's a hard Bukkit limitation, not a bug.
        boolean overworldIsPrimary = isPrimaryWorld(overworldName);

        java.util.List<String> liveUnload = new java.util.ArrayList<>();
        if (doNether) liveUnload.add(netherName);
        if (doEnd) liveUnload.add(endName);
        if (doOverworld && !overworldIsPrimary) liveUnload.add(overworldName);

        unloadAllWithRetry(liveUnload, 0, () -> {
            java.util.List<String> stillLoaded = liveUnload.stream()
                    .filter(n -> Bukkit.getWorld(n) != null)
                    .toList();

            if (!stillLoaded.isEmpty()) {
                Bukkit.broadcastMessage(color("&c&lReset ABORTED for: " + stillLoaded
                        + " — could not unload. No files were touched for these. Try again, or restart and retry."));
                plugin.getLogger().severe("Reset aborted for: " + stillLoaded);
                Bukkit.setWhitelist(restoreWhitelist);
                resetInProgress = false;
                return;
            }

            // Delete folders off the main thread (pure disk I/O).
            CompletableFuture.runAsync(() -> {
                if (doNether) deleteWorldFolder(netherName);
                if (doEnd) deleteWorldFolder(endName);
                if (doOverworld && !overworldIsPrimary) deleteWorldFolder(overworldName);

                if (doOverworld && overworldIsPrimary) {
                    // Can't unload it live — turn off autosave so nothing re-writes the
                    // folder we're about to delete, then delete it. It regenerates fresh
                    // on the next server boot, using the seed we write to server.properties.
                    World w = Bukkit.getWorld(overworldName);
                    if (w != null) {
                        Bukkit.getScheduler().runTask(plugin, () -> w.setAutoSave(false));
                    }
                    deleteWorldFolder(overworldName);
                    if (randomizeSeeds) {
                        writeLevelSeedToServerProperties(overworldSeed);
                    }
                }
            }).thenRun(() -> Bukkit.getScheduler().runTask(plugin, () -> {
                // Recreate the non-primary worlds live, on the main thread.
                if (doNether) {
                    new WorldCreator(netherName)
                            .environment(World.Environment.NETHER)
                            .seed(netherSeed)
                            .createWorld();
                }
                if (doEnd) {
                    new WorldCreator(endName)
                            .environment(World.Environment.THE_END)
                            .seed(endSeed)
                            .createWorld();
                }
                if (doOverworld && !overworldIsPrimary) {
                    new WorldCreator(overworldName)
                            .environment(World.Environment.NORMAL)
                            .type(WorldType.NORMAL)
                            .seed(overworldSeed)
                            .createWorld();
                }

                // Homes / economy / kits / etc. inside EssentialsX userdata.
                if (cfg.getBoolean("options.reset-homes", true)) {
                    clearEssentialsKeys();
                }

                // Anything else the server owner listed: AH data, shop/order data,
                // economy plugin folders, etc.
                wipeExtraDataPaths();

                // Restore whitelist state and announce.
                Bukkit.setWhitelist(restoreWhitelist);
                String done = prefixed("broadcast-done")
                        .replace("{overworld_seed}", String.valueOf(overworldSeed))
                        .replace("{nether_seed}", String.valueOf(netherSeed))
                        .replace("{end_seed}", String.valueOf(endSeed));
                Bukkit.broadcastMessage(color(done));
                plugin.getLogger().info("Reset complete. Seeds -> overworld=" + overworldSeed
                        + " nether=" + netherSeed + " end=" + endSeed);

                if (doOverworld && overworldIsPrimary) {
                    Bukkit.broadcastMessage(color("&e&lOverworld data cleared and new seed saved. "
                            + "RESTART THE SERVER NOW to finish generating the new Overworld "
                            + "(this one step can't be done live — it's a Bukkit limitation on the primary world)."));
                    plugin.getLogger().warning("ACTION NEEDED: restart the server now to finish generating the new Overworld.");
                }

                resetInProgress = false;
            }));
        });
    }

    /**
     * True if worldName matches the server's primary world (server.properties'
     * level-name) — Bukkit will never let that one be unloaded while running.
     */
    private boolean isPrimaryWorld(String worldName) {
        if (Bukkit.getWorlds().isEmpty()) return false;
        return Bukkit.getWorlds().get(0).getName().equalsIgnoreCase(worldName);
    }

    /**
     * Updates (or adds) the level-seed line in server.properties so the primary world
     * regenerates with the intended seed on next boot, since we can't set that live.
     */
    private void writeLevelSeedToServerProperties(long seed) {
        File propsFile = new File(plugin.getServer().getWorldContainer().getParentFile(), "server.properties");
        if (!propsFile.isFile()) {
            plugin.getLogger().warning("Could not find server.properties to write the new seed into.");
            return;
        }
        try {
            java.util.List<String> lines = Files.readAllLines(propsFile.toPath());
            boolean found = false;
            for (int i = 0; i < lines.size(); i++) {
                if (lines.get(i).startsWith("level-seed=")) {
                    lines.set(i, "level-seed=" + seed);
                    found = true;
                    break;
                }
            }
            if (!found) {
                lines.add("level-seed=" + seed);
            }
            Files.write(propsFile.toPath(), lines);
            plugin.getLogger().info("Wrote new level-seed=" + seed + " to server.properties.");
        } catch (IOException e) {
            plugin.getLogger().warning("Failed to update server.properties with new seed: " + e.getMessage());
        }
    }

    /**
     * Attempts to unload every world in {@code names}, retrying any that fail (up to
     * ~5s total) before giving up and calling {@code after} regardless of outcome —
     * the caller checks which worlds are still loaded and aborts loudly if any are.
     */
    private void unloadAllWithRetry(java.util.List<String> names, int attempt, Runnable after) {
        boolean anyStillLoaded = false;
        for (String name : names) {
            World w = Bukkit.getWorld(name);
            if (w != null) {
                boolean ok = Bukkit.unloadWorld(w, false);
                if (!ok) anyStillLoaded = true;
            }
        }
        if (anyStillLoaded && attempt < 100) { // up to ~5s of retries
            Bukkit.getScheduler().runTaskLater(plugin, () -> unloadAllWithRetry(names, attempt + 1, after), 1L);
            return;
        }
        after.run();
    }

    private long currentSeedOrRandom(String worldName) {
        World w = Bukkit.getWorld(worldName);
        return (w != null) ? w.getSeed() : new Random().nextLong();
    }

    private void deleteWorldFolder(String worldName) {
        Path worldPath = new File(Bukkit.getWorldContainer(), worldName).toPath();
        if (!Files.exists(worldPath)) return;
        try {
            deleteDirectoryRecursively(worldPath);
        } catch (IOException e) {
            plugin.getLogger().warning("Failed to fully delete world folder '" + worldName + "': " + e.getMessage());
        }
    }

    /**
     * Strips the configured top-level keys (default: just "homes") out of every
     * EssentialsX userdata YAML file, if the Essentials userdata folder exists. This
     * edits the YAML directly and does not require Essentials as a dependency, and
     * touches nothing outside the listed keys (e.g. leaves the player's UUID/username
     * mapping, and any key you didn't list, alone).
     */
    private void clearEssentialsKeys() {
        var cfg = plugin.getConfig();
        String path = cfg.getString("options.essentials-userdata-path", "plugins/Essentials/userdata");
        java.util.List<String> keys = cfg.getStringList("options.essentials-clear-keys");
        if (keys.isEmpty()) keys = java.util.List.of("homes");

        File dir = new File(plugin.getServer().getWorldContainer().getParentFile(), path);
        if (!dir.isDirectory()) {
            return; // Essentials not installed / no userdata yet — nothing to do.
        }
        File[] files = dir.listFiles((d, name) -> name.toLowerCase().endsWith(".yml"));
        if (files == null) return;

        int cleared = 0;
        for (File f : files) {
            try {
                YamlConfiguration yaml = YamlConfiguration.loadConfiguration(f);
                boolean changed = false;
                for (String key : keys) {
                    if (yaml.contains(key)) {
                        yaml.set(key, null);
                        changed = true;
                    }
                }
                if (changed) {
                    yaml.save(f);
                    cleared++;
                }
            } catch (IOException e) {
                plugin.getLogger().warning("Could not clear data in " + f.getName() + ": " + e.getMessage());
            }
        }
        plugin.getLogger().info("Cleared " + keys + " for " + cleared + " player file(s).");
    }

    /**
     * Deletes every path listed under options.extra-data-paths in config.yml, relative
     * to the server root (the folder server.jar lives in). This is how auction house
     * listings, shop/order data, economy plugin folders, etc. get wiped — it's fully
     * config-driven so it only ever touches what the server owner explicitly listed.
     * Each entry can be a single file or a whole folder.
     */
    private void wipeExtraDataPaths() {
        java.util.List<String> paths = plugin.getConfig().getStringList("extra-data-paths");
        if (paths.isEmpty()) return;

        File serverRoot = plugin.getServer().getWorldContainer().getParentFile();
        for (String rel : paths) {
            File target = new File(serverRoot, rel);
            if (!target.exists()) {
                plugin.getLogger().info("extra-data-paths: '" + rel + "' does not exist, skipping.");
                continue;
            }
            try {
                if (target.isDirectory()) {
                    deleteDirectoryRecursively(target.toPath());
                } else {
                    Files.delete(target.toPath());
                }
                plugin.getLogger().info("extra-data-paths: deleted '" + rel + "'.");
            } catch (IOException e) {
                plugin.getLogger().warning("Failed to delete extra data path '" + rel + "': " + e.getMessage());
            }
        }
    }

    private void deleteDirectoryRecursively(Path dirPath) throws IOException {
        Files.walkFileTree(dirPath, new SimpleFileVisitor<>() {
            @Override
            public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                Files.delete(file);
                return FileVisitResult.CONTINUE;
            }

            @Override
            public FileVisitResult postVisitDirectory(Path dir, IOException exc) throws IOException {
                Files.delete(dir);
                return FileVisitResult.CONTINUE;
            }
        });
    }
}
